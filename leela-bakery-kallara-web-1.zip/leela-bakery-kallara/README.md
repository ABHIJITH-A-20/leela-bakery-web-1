# bootstrap-bakery
Starter files for the project

In this repo you'll find all the files necessary to get you started with this project. Once completed feel free to modify as you'd like.
